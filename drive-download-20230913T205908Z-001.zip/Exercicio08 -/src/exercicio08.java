public class exercicio08 {
    // não consegui fazer 
}
